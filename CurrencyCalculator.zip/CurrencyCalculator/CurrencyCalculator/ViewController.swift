//
//  ViewController.swift
//  CurrencyCalculator
//
//  Created by Fazil on 1/5/18.
//  Copyright © 2018 Fazil. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    struct Currency: Decodable {
        let base: String
        let date: String
        let rates: [String: Double]
    }
    

    @IBOutlet weak var Ratefield: UITextField!
    @IBOutlet weak var convertTableview: UITableView!
    
    var usd:Currency?
    var baseRate = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        convertTableview.dataSource = self
        convertTableview.allowsSelection = false
        convertTableview.showsVerticalScrollIndicator = false
        Ratefield.textAlignment = .center
        fetchData()
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let currencyFetched = usd {
            return currencyFetched.rates.count
            
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        
        if let currencyFetched = usd {
            cell.textLabel?.text = Array(currencyFetched.rates.keys)[indexPath.row]
            let selectedRate = baseRate * Array(currencyFetched.rates.values)[indexPath.row]
            cell.detailTextLabel?.text = "\(selectedRate)"
            return cell
        }
        return UITableViewCell()
    }

    
    
    
    @IBAction func convertBut(_ sender: Any)
    {
        if let iGetString = Ratefield.text {
            if let isDouble = Double(iGetString) {
                baseRate = isDouble
                fetchData()
            }
        }
        
    }
    
    func fetchData() {
        let url = URL(string: "https://api.fixer.io/latest?base=USD")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error == nil {
                
                do {
                    self.usd = try JSONDecoder().decode(Currency.self, from: data!)
                } catch {
                    print("Parse Error")
                }
                DispatchQueue.main.async {
                  self.convertTableview.reloadData()
                }
            } else {
                print("Error")
            }
        } .resume()
        
        
    }
    
    
}

